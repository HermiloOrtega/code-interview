//
//  takehome.h
//  OsensaISE
//
//  Created by Jose Hermilo Ortega Martinez on 2020-06-26.
//  Copyright © 2020 Jose Hermilo Ortega Martinez. All rights reserved.
//

#ifndef takehome_h
#define takehome_h

#include <stdio.h>

#endif /* takehome_h */
